h1 = figure('Position',[1 scrsz(4) scrsz(3)/2 scrsz(4)/2]) ;

hist(R70(DBIDX)) ; 
xlabel('ratio') ; set(gca, 'fontsize', 20) ;
exportgraphics(h1, 'GoodRatiohistogram.pdf', 'ContentType', 'vector', 'BackgroundColor','none');


fprintf('\n subject-based good REI ratio, med+-MAD, mean+-SD\n') ;
disp([median(R70(DBIDX)) mad(R70(DBIDX)) mean(R70(DBIDX)) std(R70(DBIDX))]) ;
fprintf('subject-based good REI ratio, min-max\n\n') ;
disp([min(R70(DBIDX)) max(R70(DBIDX))])

