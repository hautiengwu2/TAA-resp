function [ACC, SEN, SPE, PRE, F1] = PerformanceEvaluation(CM)

ACC = sum(diag(CM)) ./ sum(CM(:)) ;

if sum(CM(2,:))
    SEN = CM(2,2) ./ sum(CM(2,:)) ;
else
    SEN = nan ;
end

if sum(CM(1,:))
    SPE = CM(1,1) ./ sum(CM(1,:)) ;
else
    SPE = nan ;
end

if sum(CM(:,2))
    PRE = CM(2,2) ./ sum(CM(:,2)) ;
else
    PRE = nan ;
end

if PRE + SEN
    F1 = 2*PRE*SEN ./ (PRE + SEN) ;
else
    F1 = nan ;
end