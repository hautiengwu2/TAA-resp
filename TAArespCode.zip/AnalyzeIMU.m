clear ; close all ;


addpath('./SST') ;
addpath('./SAMD') ;


% this is the folder of some example datasets
folder = './YOURDB';
ggg = dir([folder '/*.mat']) ;

scrsz = get(0,'ScreenSize') ;

% these are cases having experts' labels
DBIDX = 1:length(ggg) ;



%% Step 0: prepare data. Load a real-world data (choose one)

CORRflow = {} ;
CORRABD = {} ;
CORRTHO = {} ;
STAGE = {} ;
APNEA = {} ;
LABEL = {} ;

REI1onlyIMU = {} ;

flag1 = 0 ; flag2 = 0 ;

% randomly select 500 directions to evaluate REI
S2P = randn(3, 500) ;
for jj = 1: 500
    S2P(:, jj) = S2P(:, jj) ./ norm(S2P(:, jj)) ;
end


Wn = [0.1 1]/(5/2);
[bbb, aaa] = butter(4, Wn, 'bandpass');

global plotTFR ;
plotTFR = 0 ;

if plotTFR
    global h0 ;
    h0 = figure('Position',[1 scrsz(4) scrsz(3)/2 scrsz(4)]) ;
end


% save the analysis result in RESULT.mat.
if ~exist('RESULT.mat')

% if want to generate figures for paper, use plotSIGNAL + DBIDX
for index = DBIDX %1:length(ggg)

    t1 = tic ;
    disp([index length(ggg)])
    load([folder '/' ggg(index).name]);


    if exist(['annotations/Annotations-' ggg(index).name(1:end-4) '-' num2str(index) '.mat'])
        fprintf(['QQ--find annotations of ' num2str(index) '--' ggg(index).name(1:end-4) '\n']) ;
        load(['annotations/Annotations-' ggg(index).name(1:end-4) '-' num2str(index)]) ;
        disp(unique(annotations(find(~isnan(annotations))))')
    else
        annotations = nan(1000, 1) ;
    end


    % TipTraQ IMU = 50 Hz
    % clean up each channel via cumsum
    x0 = database.imu.x.signal ; x0 = x0 - mean(x0) ;
    trend = medfilt1(x0, 10*double(database.imu.y.fs)) ;
    x1 = x0 - trend ;
    x2 = cumsum(x1) / double(database.imu.y.fs) ;
    trend = medfilt1(x2, 10*double(database.imu.y.fs)) ;
    x3 = x2 - trend ;
    x = x3(1: 10*floor(length(x2)/10)) ;
    xaxis = x(1:10:end) ; % reduce to 5Hz
    x0axis = database.imu.x.signal(1:10:end) ;

    x0 = database.imu.y.signal ; x0 = x0 - mean(x0) ;
    trend = medfilt1(x0, 10*double(database.imu.y.fs)) ;
    x1 = x0 - trend ;
    x2 = cumsum(x1) / double(database.imu.y.fs) ;
    trend = medfilt1(x2, 10*double(database.imu.y.fs)) ;
    x3 = x2 - trend ;
    x = x3(1: 10*floor(length(x2)/10)) ;
    yaxis = x(1:10:end) ; % reduce to 5Hz
    y0axis = database.imu.y.signal(1:10:end) ;

    x0 = database.imu.z.signal ; x0 = x0 - mean(x0) ;
    trend = medfilt1(x0, 10*double(database.imu.y.fs)) ;
    x1 = x0 - trend ;
    x2 = cumsum(x1) / double(database.imu.y.fs) ;
    trend = medfilt1(x2, 10*double(database.imu.y.fs)) ;
    x3 = x2 - trend ;
    x = x3(1: 10*floor(length(x2)/10)) ;
    zaxis = x(1:10:end) ; % reduce to 5Hz
    z0axis = database.imu.z.signal(1:10:end) ;

    % remove outliers
    xaxis(abs(xaxis)>500) = 0 ;
    yaxis(abs(yaxis)>500) = 0 ;
    zaxis(abs(zaxis)>500) = 0 ;

    % the IMU signal
    X = [xaxis ; yaxis ; zaxis]' ;
    X0 = [x0axis ; y0axis ; z0axis]' ;

    % get ground truth resp signals
    airflow = database.airflow.signal ; % true signal
    airflow = airflow(1:20:end) ; % reduce to 5Hz - original 100hz

    thorax = database.thorax.signal ; % true signal
    thorax = thorax(1:20:end) ; % reduce to 5Hz - original 100hz

    abdomen = database.abdomen.signal ; % true signal
    abdomen = abdomen(1:20:end) ; % reduce to 5Hz - original 100hz

    Hz = 5 ;

    % each window is 60s long, with overlap 30s
    window_length = 60 ; % sec
    boundary_length = 0 ; % sec
    SEGNO = floor( (length(xaxis) / 5 - boundary_length) / window_length) ;

    CORRflow{index} = zeros(SEGNO, 1) ;
    CORRABD{index} = zeros(SEGNO, 1) ;
    CORRTHO{index} = zeros(SEGNO, 1) ;
    
    for sIDX = 1: SEGNO

        waitbar(sIDX/SEGNO)
        IDX = (sIDX-1) * (window_length - boundary_length) * Hz + 1 : ...
            ((sIDX-1) * (window_length - boundary_length) + window_length) * Hz ;

        eIDX = IDX(1)-50 : IDX(end)+50 ;
        eIDX(eIDX<1) = 1 ;
        eIDX(eIDX>length(X(:,1))) = length(X(:,1)) ;

        % extended one to avoid boundary effect
        ex = X(eIDX, :) ;
        ex(:, 1) = ex(:, 1) - mean(x(:, 1)) ;
        ex(:, 2) = ex(:, 2) - mean(x(:, 2)) ;
        ex(:, 3) = ex(:, 3) - mean(x(:, 3)) ;

        % normal one
        x = X(IDX, :) ;
        x(:, 1) = x(:, 1) - mean(x(:, 1)) ;
        x(:, 2) = x(:, 2) - mean(x(:, 2)) ;
        x(:, 3) = x(:, 3) - mean(x(:, 3)) ;
        x0 = X0(IDX, :) ;

        FLOW = airflow(IDX) ;
        THO = thorax(IDX) ; THO = THO - mean(THO) ;
        ABD = abdomen(IDX); ABD = ABD - mean(ABD) ;


        % determine IMU-resp
        xi = Hz * (0:window_length*Hz/2-1) / (window_length*Hz) ;
        idx = find(xi > 0.1 & xi < 0.4) ;
        xhat = zeros(length(idx), 3) ;
        for ss = 1: 3
            tmp = fft(x(:, ss)) ./ norm(x(:, ss)) ; xhat(:, ss) = tmp(idx) ;
        end

        % evm = the optimal resp from linear combination of x,y,z WITHOUT THO
        tmp = max(abs(xhat * S2P), [], 1) ;
        [~, idx] = max(tmp) ;

        % construct the extended optimal resp
        evm0 = ex * S2P(:, idx(1)) ;
        evm = filtfilt(bbb, aaa, evm0) ;
        vm0 = x * S2P(:, idx(1)) ;
        vm = filtfilt(bbb, aaa, vm0) ;


        % evaluate REI0 (imperfect version to speed up)
        xhat = fft(vm, length(vm)*3) ;
        xi = Hz * (0:length(xhat)/2-1) / length(xhat) ;
        idx = find(xi > 0.1 & xi < 0.4) ;
        [~, tmp] = max(abs(xhat(idx))) ;
        idx = idx(1) + tmp - 1 ;
        idx1 = xi > xi(idx)-0.05 & xi < xi(idx)+0.05 ;
        idx2 = xi > 0.05 & xi < 1 ;
        REI0 = sum(abs(xhat(idx1)).^2) ./ sum(abs(xhat(idx2)).^2) ;

        if REI0 > 1
            REI0 = 0 ;
        end


        % evaluate REI using SST+unwarping only when REI0>0.2 to save time
        % (not really necessary)
        if REI0 > 0.2
            [AM, PHI, IRR] = generatePhase(evm, Hz) ;

            % if less than 4 cycles detected in 60 seconds, cannot be good!
            if PHI(end) > 4
                [OUTPUT, time_ext] = warpsignal(vm, (1:length(vm))'/Hz, PHI) ;
                UWHz = round(1./ (time_ext(2)-time_ext(1))) ;
                xhat = fft(OUTPUT, length(OUTPUT)*3) ;
                xi = UWHz * (1:length(xhat)/2) / length(xhat) ;
                idx1 = find(xi > 0.9 & xi < 1.1) ;
                idx2 = find(xi > 0.1 & xi < 3) ;
                REI1 = sum(abs(xhat(idx1)).^2) ./ sum(abs(xhat(idx2)).^2) ;
                REI1 = round(1000*REI1)/1000 ;
                
                if isempty(REI1) ; REI1 = 0 ; end
                
            else
                REI1 = 0 ; 
            end
        else
            REI1 = 0 ; 
        end

        REI1onlyIMU{index}(sIDX) = REI1 ;


        % vm0 = the normalized vm
        vm0 = vm / norm(vm) ;

        % V = -15~15 shifted vm0
        V = [] ;
        for ss = -15: 15
            tmp = circshift(vm0, ss) ;
            tmp = tmp ./ norm(tmp(15:end-14)) ;
            V = [V tmp] ;
        end

        % evaluate the maximal correlation between true resp signal and vm0
        % with the optimal shifts
        tmp1 = round(100*max(FLOW(15:end-14)*V(15:end-14,:)/norm(FLOW(15:end-14))))/100 ;
        tmp2 = round(100*max(THO(15:end-14)*V(15:end-14,:)/norm(THO(15:end-14))))/100 ;
        tmp3 = round(100*max(ABD(15:end-14)*V(15:end-14,:)/norm(ABD(15:end-14))))/100 ;

        CORRflow{index}(sIDX) = tmp1 ;
        CORRTHO{index}(sIDX) = tmp2 ;
        CORRABD{index}(sIDX) = tmp3 ;

    end

    toc(t1)
    save('RESULT', 'CORRflow', 'CORRABD', 'CORRTHO', 'LABEL', 'REI1onlyIMU') ;

end

else

    fprintf('Load existing result \n') ;
    load('RESULT.mat') ;
end




%%
% get experts' labels



fprintf('Collect experts'' labels and indices\n') ;
for index = DBIDX

    if exist(['annotations/Annotations-' ggg(index).name(1:end-4) '-' num2str(index) '.mat'])
        fprintf(['find annotations of ' num2str(index) '--' ggg(index).name(1:end-4) '\n']) ;
        load(['annotations/Annotations-' ggg(index).name(1:end-4) '-' num2str(index)]) ;
    else
        annotations = nan(1000, 1) ;
    end
    
    % all amplitude less than 5 are BAD.
    load([folder '/' ggg(index).name]);


    % get apnea label
    apnea = double(database.apnea_1blabel.signal) ; % 2hz
    apnea = median(reshape(apnea(1:120*floor(length(apnea)/120)),...
        120, floor(length(apnea)/120) ), 1) ;
    apnea = round(apnea) ; %1/60 hz (unit=epoch)


    % get sleep stage
    stage = double(database.sleep_stage.signal(60:60:end)) ; %1/30 hz (unit=epoch)

    genIMUresp ;
   
    annotations = annotations(1:length(stage)) ;

    % in some cases, only 1/3 segments are labeled. Collect them
    Qidx = find(~isnan(annotations)) ;


    %annotations(AMP < 5) = 0 ;
    LABEL{index} = annotations(Qidx) ;
    STAGE{index} = stage(Qidx) ; %(1:SegNO) ;
    APNEA{index} = apnea(Qidx) ; %(1:SegNO) ;
    REI1onlyIMU{index} = REI1onlyIMU{index}(Qidx) ;
    CORRflow{index} = CORRflow{index}(Qidx) ;
    CORRTHO{index} = CORRTHO{index}(Qidx) ;
    CORRABD{index} = CORRABD{index}(Qidx) ;
    
    AMPl{index} = AMP(Qidx) ;
    AMPTHOl{index} = AMPTHO(Qidx) ;
    AMPABDl{index} = AMPABD(Qidx) ;
    AMPflowl{index} = AMPflow(Qidx) ;

end




%%
% prepare data for all subjects
% the CORR distribution of vm WITHOUT using THO
ALLCORRflow = [] ;
ALLCORRTHO = [] ;
ALLCORRABD = [] ;
ALLREI1 = [] ;
ALLSTAGE = [] ;
ALLAPNEA = [] ;
ALLLABEL = [] ;
ALLAMP = [] ;
ALLAMPABD = [] ;
ALLAMPTHO = [] ;
ALLAMPflow = [] ;

% ratio of LABEL>0 (moderate or good)
R70 = zeros(length(ggg), 1) ;  

for jj = DBIDX

    ALLCORRflow = [ALLCORRflow; CORRflow{jj}] ;
    ALLCORRTHO = [ALLCORRTHO; CORRTHO{jj}] ;
    ALLCORRABD = [ALLCORRABD; CORRABD{jj}] ;
    ALLREI1 = [ALLREI1; REI1onlyIMU{jj}'] ;
    ALLSTAGE = [ALLSTAGE; STAGE{jj}'] ;
    ALLAPNEA = [ALLAPNEA; APNEA{jj}'] ;
    ALLLABEL = [ALLLABEL; LABEL{jj}] ;
    ALLAMP = [ALLAMP; AMPl{jj}] ;
    ALLAMPABD = [ALLAMPABD; AMPABDl{jj}] ;
    ALLAMPTHO = [ALLAMPTHO; AMPTHOl{jj}] ;
    ALLAMPflow = [ALLAMPflow; AMPflowl{jj}] ;

    idx = find(~isnan(LABEL{jj})) ;
    R70(jj) = length(find(LABEL{jj}(idx)>0)) / length(LABEL{jj}(idx)) ;

end

fprintf('expert''s label number\n') ;
idx = find(~isnan(ALLLABEL)) ;
disp([length(ALLLABEL(idx)) sum(ALLLABEL(idx)==0) sum(ALLLABEL(idx)==1) sum(ALLLABEL(idx)==2)]) ;






%% Report percentage of high quality IMU-resp of different status

SLEEPSTAGE = {'Wake', 'REM', 'N1', 'N2', 'N3'} ;
APNEASTATUS = {'no-apnea' 'hypopnea' 'apnea'} ;

ALLAPNEA(ALLAPNEA==1) = 2 ; % OSA+CSA
ALLAPNEA(ALLAPNEA==2) = 2 ; % OSA+CSA
ALLAPNEA(ALLAPNEA==3) = 1 ; % hypopnea

ReportQualityvsGroups ;




%% run classification training/testing

ReportREIpredQuality




%% show correlation with other channels

ReportCORRwithOthers



%% generate violin plot of REI vs quality groups

ReportQualityvsREI








%% plot histogram of moderate+good rato

ReportHistogramHighQuality




%% REI vs sleep stages

ReportREIvsSleep



%% REI vs sleep apnea

ReportREIvsApnea



%% use REI to predict apnea

ReportREIpredApnea ;




