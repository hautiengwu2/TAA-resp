sleepREI1 = {} ; 
dataREI1 = [] ; groupREI1 = [] ;


for jj = 1: 5
    idx = find(ALLSTAGE == jj+10) ;
    sleepREI1{jj} = ALLREI1(idx) ;
    dataREI1 = [dataREI1; ALLREI1(idx)] ;
    groupREI1 = [groupREI1; jj*ones(size(idx))] ;
end

[p, tbl, stats] = kruskalwallis(dataREI1, groupREI1);
results = multcompare(stats, 'CType', 'bonferroni');


SLEEPSTAGE = {'Wake', 'REM', 'N1', 'N2', 'N3'} ;

h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)/2]) ;
[h,L,MX,MED] = violin(sleepREI1, 'facealpha', 0.2, 'bw', 0.02) ;
set(gca,'TickLabelInterpreter', 'latex');
set(gca,'xtick',1:length(SLEEPSTAGE))
set(gca,'xticklabel', SLEEPSTAGE) ; ylim([0 1])
xtickangle(25) ; set(gca,'fontsize', 16) ; legend off
ylabel('RMI', 'interpreter','latex')

exportgraphics(h1, 'RMI_SleepStage.pdf', 'ContentType', 'vector', 'BackgroundColor','none');


fprintf('mean RMI of 5 groups\n') ;
disp(MX)

fprintf('SD RMI of 5 groups\n') ;
disp([std(sleepREI1{1}) std(sleepREI1{2}) std(sleepREI1{3}) std(sleepREI1{4}) std(sleepREI1{5})])

fprintf('median RMI of 5 groups\n') ;
disp(MED)

fprintf('MAD RMI of 5 groups\n') ;
disp([mad(sleepREI1{1}) mad(sleepREI1{2}) mad(sleepREI1{3}) mad(sleepREI1{4}) mad(sleepREI1{5})])

