% remove NaN
idx1 = ~isnan(ALLCORRflow+ALLCORRTHO+ALLCORRABD+ALLSTAGE+ALLAPNEA) ;

if sum(isnan(ALLCORRflow+ALLCORRTHO+ALLCORRABD+ALLSTAGE+ALLAPNEA))
    fprintf(['Exist nan entries... ' num2str(sum(isnan(ALLCORRflow+ALLCORRTHO+ALLCORRABD+ALLSTAGE+ALLAPNEA)))...
        '/' num2str(length(ALLCORRflow)) ' -- remove\n']) ; 
end

ALLCORRflowq = ALLCORRflow(idx1) ;
ALLCORRTHOq = ALLCORRTHO(idx1) ;
ALLCORRABDq = ALLCORRABD(idx1) ;
ALLREI1q = ALLREI1(idx1) ;
ALLSTAGEq = ALLSTAGE(idx1) ;
ALLAPNEAq = ALLAPNEA(idx1) ;
ALLLABELq = ALLLABEL(idx1) ;
ALLAMPq = ALLAMP(idx1) ;
ALLAMPABDq = ALLAMPABD(idx1) ;
ALLAMPTHOq = ALLAMPTHO(idx1) ;
ALLAMPflowq = ALLAMPflow(idx1) ;

MODALITYNAME = {'airflow', 'THO', 'ABD'} ;



%% correlation violin plots/HQ segments
idx2 = find(ALLLABELq == 1 | ALLLABELq == 2) ;

CORRlist{1} = ALLCORRflowq(idx2) ;
CORRlist{2} = ALLCORRTHOq(idx2) ;
CORRlist{3} = ALLCORRABDq(idx2) ;

h1 = figure('Position',[1 scrsz(4) scrsz(3)*3/5 scrsz(4)/2]) ;
[h,L,MX,MED] = violin(CORRlist, 'facealpha', 0.2, 'bw', 0.02) ;
set(gca,'TickLabelInterpreter', 'latex');
set(gca,'xtick',1:length(MODALITYNAME))
set(gca,'xticklabel', MODALITYNAME) ; ylim([0 1])
xtickangle(25) ; set(gca,'fontsize', 16) ; legend off
ylabel('$\mathrm{CORR}_s$', 'interpreter','latex')

exportgraphics(h1, 'CORR_distributionALL.pdf', 'ContentType', 'vector', 'BackgroundColor','none');


fprintf('HQ: mean CORRs with other channels\n') ;
disp(MX)

fprintf('HQ: SD CORRs with other channels\n') ;
disp([std(CORRlist{1}) std(CORRlist{2}) std(CORRlist{3})])

fprintf('HQ: median CORRs with other channels\n') ;
disp(MED)

fprintf('HQ: MAD CORRs with other channels\n') ;
disp([mad(CORRlist{1}) mad(CORRlist{2}) mad(CORRlist{3})])



%% correlation difference significance/HQ segments
fprintf('Is correlation between IMU-resp and THO different from that of ABD? HQ segments\n')
[p1,h,stats] = signrank(ALLCORRTHOq(idx2), ALLCORRflowq(idx2));
[p2,h,stats] = signrank(ALLCORRABDq(idx2), ALLCORRflowq(idx2));
[p3,h,stats] = signrank(ALLCORRABDq(idx2), ALLCORRTHOq(idx2));
disp([p1 p2 p3])



%% correlation violin plots/all segments
CORRlist{1} = ALLCORRflowq ;
CORRlist{2} = ALLCORRTHOq ;
CORRlist{3} = ALLCORRABDq ;

h1 = figure('Position',[1 scrsz(4) scrsz(3)*3/5 scrsz(4)/2]) ;
[h,L,MX,MED] = violin(CORRlist, 'facealpha', 0.2, 'bw', 0.02) ;
set(gca,'TickLabelInterpreter', 'latex');
set(gca,'xtick',1:length(MODALITYNAME))
set(gca,'xticklabel', MODALITYNAME) ; ylim([0 1])
xtickangle(25) ; set(gca,'fontsize', 16) ; legend off
ylabel('$\mathrm{CORR}_s$', 'interpreter','latex')

exportgraphics(h1, 'CORR_distributionALL.pdf', 'ContentType', 'vector', 'BackgroundColor','none');


fprintf('ALL segments: mean CORRs with other channels\n') ;
disp(MX)

fprintf('ALL segments: SD CORRs with other channels\n') ;
disp([std(CORRlist{1}) std(CORRlist{2}) std(CORRlist{3})])

fprintf('ALL segments: median CORRs with other channels\n') ;
disp(MED)

fprintf('ALL segments: MAD CORRs with other channels\n') ;
disp([mad(CORRlist{1}) mad(CORRlist{2}) mad(CORRlist{3})])




%% correlation difference significance/All segments
fprintf('Is correlation between IMU-resp and THO different from that of ABD? All segments\n')
[p1,h,stats] = signrank(ALLCORRTHOq, ALLCORRflowq);
[p2,h,stats] = signrank(ALLCORRABDq, ALLCORRflowq);
[p3,h,stats] = signrank(ALLCORRABDq, ALLCORRTHOq);
disp([p1 p2 p3])















%% amplitude relationship with other channels/HQ segments
h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)*0.4]) ;
subplot(131) ; hist2d(log(1+ALLAMPq(idx2)), log(1+ALLAMPTHOq(idx2)), 100) ;
set(gca, 'fontsize', 16) ; axis tight
xlabel('$\log(1+$TAA-resp magnitude)','interpreter','latex') ; 
ylabel('$\log(1+$THO magnitude)','interpreter','latex') ; 
axis xy ; colorbar
subplot(132) ; hist2d(log(1+ALLAMPq(idx2)), log(1+ALLAMPABDq(idx2)), 100) ;
set(gca, 'fontsize', 16) ; axis tight
xlabel('$\log(1+$TAA-resp magnitude)','interpreter','latex') ; 
ylabel('$\log(1+$ABD magnitude)','interpreter','latex') ; axis xy ; colorbar
subplot(133) ; hist2d(log(1+ALLAMPq(idx2)), log(1+ALLAMPflowq(idx2)), 100) ;
set(gca, 'fontsize', 16) ; axis tight
xlabel('$\log(1+$TAA-resp magnitude)','interpreter','latex') ; 
ylabel('$\log(1+$airflow magnitude)','interpreter','latex') ; axis xy ; colorbar
colormap(1-gray)

exportgraphics(h1, 'AmplitudeRelationshipHQ.pdf', 'ContentType', 'vector', 'BackgroundColor','none');




%%


% regression fit.
x = log(1+ALLAMPq(idx2)) ;
y = log(1+ALLAMPTHOq(idx2)) ;

maxDegree = 3 ;
AIC = zeros(maxDegree,1);
models = cell(maxDegree,1);

for d = 1:maxDegree
    mdl = fitlm(x, y, sprintf('poly%d', d));
    AIC(d) = mdl.ModelCriterion.AIC;
    models{d} = mdl;
end

[~, bestIdx] = min(AIC);
bestModel = models{bestIdx};

fprintf('\nHQ -- Best degree for THO: %d\n', bestIdx)
disp(bestModel)


y = log(1+ALLAMPABDq(idx2)) ;
AIC = zeros(maxDegree,1);
models = cell(maxDegree,1);

for d = 1:maxDegree
    mdl = fitlm(x, y, sprintf('poly%d', d));
    AIC(d) = mdl.ModelCriterion.AIC;
    models{d} = mdl;
end

[~, bestIdx] = min(AIC);
bestModel = models{bestIdx};

fprintf('\nHQ -- Best degree for ABD: %d\n', bestIdx)
disp(bestModel)


y = log(1+ALLAMPflowq(idx2)) ;
AIC = zeros(maxDegree,1);
models = cell(maxDegree,1);

for d = 1:maxDegree
    mdl = fitlm(x, y, sprintf('poly%d', d));
    AIC(d) = mdl.ModelCriterion.AIC;
    models{d} = mdl;
end

[~, bestIdx] = min(AIC);
bestModel = models{bestIdx};

fprintf('\nHQ -- Best degree for airflow: %d\n', bestIdx)
disp(bestModel)







%% amplitude relationship with other channels/all segments
h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)*0.4]) ;
subplot(131) ; hist2d(log(1+ALLAMPq), log(1+ALLAMPTHOq), 100) ;
set(gca, 'fontsize', 16) ; axis tight
xlabel('$\log(1+$TAA-resp magnitude)','interpreter','latex') ; 
ylabel('$\log(1+$THO magnitude)','interpreter','latex') ; axis xy ; colorbar
subplot(132) ; hist2d(log(1+ALLAMPq), log(1+ALLAMPABDq), 100) ;
set(gca, 'fontsize', 16) ; axis tight
xlabel('$\log(1+$TAA-resp magnitude)','interpreter','latex') ; 
ylabel('$\log(1+$ABD magnitude)','interpreter','latex') ; axis xy ; colorbar
subplot(133) ; hist2d(log(1+ALLAMPq), log(1+ALLAMPflowq), 100) ;
set(gca, 'fontsize', 16) ; axis tight
xlabel('$\log(1+$TAA-resp magnitude)','interpreter','latex') ; 
ylabel('$\log(1+$airflow magnitude)','interpreter','latex') ; axis xy ; colorbar
colormap(1-gray)

exportgraphics(h1, 'AmplitudeRelationshipALL.pdf', 'ContentType', 'vector', 'BackgroundColor','none');



% regression fit.
x = log(1+ALLAMPq) ;
y = log(1+ALLAMPTHOq) ;

maxDegree = 3 ;
AIC = zeros(maxDegree,1);
models = cell(maxDegree,1);

for d = 1:maxDegree
    mdl = fitlm(x, y, sprintf('poly%d', d));
    AIC(d) = mdl.ModelCriterion.AIC;
    models{d} = mdl;
end

[~, bestIdx] = min(AIC);
bestModel = models{bestIdx};

fprintf('\nALL -- Best degree for THO: %d\n', bestIdx)
disp(bestModel)


y = log(1+ALLAMPABDq) ;
AIC = zeros(maxDegree,1);
models = cell(maxDegree,1);

for d = 1:maxDegree
    mdl = fitlm(x, y, sprintf('poly%d', d));
    AIC(d) = mdl.ModelCriterion.AIC;
    models{d} = mdl;
end

[~, bestIdx] = min(AIC);
bestModel = models{bestIdx};

fprintf('\nALL -- Best degree for ABD: %d\n', bestIdx)
disp(bestModel)


y = log(1+ALLAMPflowq) ;
AIC = zeros(maxDegree,1);
models = cell(maxDegree,1);

for d = 1:maxDegree
    mdl = fitlm(x, y, sprintf('poly%d', d));
    AIC(d) = mdl.ModelCriterion.AIC;
    models{d} = mdl;
end

[~, bestIdx] = min(AIC);
bestModel = models{bestIdx};

fprintf('\nALL -- Best degree for airflow: %d\n', bestIdx)
disp(bestModel)
