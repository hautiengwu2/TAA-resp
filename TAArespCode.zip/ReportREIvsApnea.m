apneaREI1 = {} ; 
dataREI1 = [] ; groupREI1 = [] ;

% collect REI over 3 apnea groups
for jj = 1: 3
    idx = find(ALLAPNEA == jj-1) ;
    apneaREI1{jj} = ALLREI1(idx) ;
    apneaLABEL{jj} = ALLLABEL(idx) ;
    % The REI values
    dataREI1 = [dataREI1; ALLREI1(idx)] ;
    % the associated apnea groups
    groupREI1 = [groupREI1; jj*ones(size(idx))] ;

    fprintf(['Over the ' APNEASTATUS{jj} ' group, the number of BAD labels\n']) ;
    disp([length(find(ALLLABEL(idx)==0)) length(idx)]); 
    
    fprintf(['Over the ' APNEASTATUS{jj} ' group, the number of MODERATE labels\n']) ;
    disp([length(find(ALLLABEL(idx)==1)) length(idx)]); 
    
    fprintf(['Over the ' APNEASTATUS{jj} ' group, the number of GOOD labels\n']) ;
    disp([length(find(ALLLABEL(idx)==2)) length(idx)]); 
end

[p, tbl, stats] = kruskalwallis(dataREI1, groupREI1);
results = multcompare(stats, 'CType', 'bonferroni');

fprintf('p-val of quality label ratio over different apnea group\n') ;
disp(p)


h1 = figure('Position',[1 scrsz(4) scrsz(3)*3/5 scrsz(4)/2]) ;
[h,L,MX,MED] = violin(apneaREI1, 'facealpha', 0.2, 'bw', 0.02) ;
set(gca,'TickLabelInterpreter', 'latex');
set(gca,'xtick',1:length(APNEASTATUS))
set(gca,'xticklabel', APNEASTATUS) ; ylim([0 1])
xtickangle(25) ; set(gca,'fontsize', 16) ; legend off
ylabel('RMI', 'interpreter','latex')

exportgraphics(h1, 'REI_APNEA.pdf', 'ContentType', 'vector', 'BackgroundColor','none');


fprintf('mean RMI of 3 groups\n') ;
disp(MX)

fprintf('SD RMI of 3 groups\n') ;
disp([std(apneaREI1{1}) std(apneaREI1{2}) std(apneaREI1{3})])

fprintf('median RMI of 3 groups\n') ;
disp(MED)

fprintf('MAD RMI of 3 groups\n') ;
disp([mad(apneaREI1{1}) mad(apneaREI1{2}) mad(apneaREI1{3})])


