CM1 = {} ;

cvDBIDX = DBIDX(DBIDX <= numel(REI1onlyIMU)) ;
cvDBIDX = cvDBIDX(~cellfun(@isempty, REI1onlyIMU(cvDBIDX))) ;

if numel(cvDBIDX) < 2
    fprintf('Skip ReportREIpredQuality: LOSOCV requires at least 2 analyzed datasets.\n') ;
    return ;
end

% LOSOCV for predicting segment quality from REI
for kk = 1:length(cvDBIDX)

    fprintf(['predict quality by REI -- LOSOCV of ' num2str(cvDBIDX(kk)) '\n']) ;
    ALLREI1Train = [] ;
    ALLSTAGETrain = [] ;
    ALLAPNEATrain = [] ;
    ALLLABELTrain = [] ;

    for jj = setdiff(cvDBIDX, cvDBIDX(kk))
        ALLREI1Train = [ALLREI1Train; REI1onlyIMU{jj}'] ;
        ALLSTAGETrain = [ALLSTAGETrain; STAGE{jj}'] ;
        ALLAPNEATrain = [ALLAPNEATrain; APNEA{jj}'] ;
        ALLLABELTrain = [ALLLABELTrain; LABEL{jj}] ;
    end



    ALLREI1Test = REI1onlyIMU{cvDBIDX(kk)} ;
    ALLSTAGETest = STAGE{cvDBIDX(kk)}' ;
    ALLAPNEATest = APNEA{cvDBIDX(kk)}' ;
    ALLLABELTest = LABEL{cvDBIDX(kk)}' ;

    

    % moderate+good=1, bad=0
    ALLLABELTrain(ALLLABELTrain==2) = 1 ;
    ALLLABELTest(ALLLABELTest==2) = 1 ;

    % downsample to balance groups
    idx = find(ALLLABELTrain==0) ;
    ALLLABELTrain([idx(1:3:end); idx(2:3:end)]) = [] ;
    ALLREI1Train([idx(1:3:end); idx(2:3:end)]) = [] ;

    fprintf(['\tGroup sizes: ' num2str(length(find(ALLLABELTrain==0))) ' '...
        num2str(length(find(ALLLABELTrain==1))) '\n'] )  ;

    % determined optimal threshold for good/bad from the training set
    [AUC1, L, R, optthreshold1, a, b, tidx] = evalROC(ALLLABELTrain, ALLREI1Train, 0) ;

    
    % apply learned threshold to the testing set
    PredTEST1 = zeros(size(ALLREI1Test)) ; 
    PredTEST1(ALLREI1Test>optthreshold1) = 1 ;
    

    % collect results
    CM1{kk} = confusionmat(ALLLABELTest, PredTEST1) ;

end



%%

for kk = 1:length(cvDBIDX)
    ACC1(kk) = sum(diag(CM1{kk})) ./ sum(CM1{kk}(:)) ;
    SEN1(kk) = CM1{kk}(2,2) ./ sum(CM1{kk}(2,:)) ;
    SPE1(kk) = CM1{kk}(1,1) ./ sum(CM1{kk}(1,:)) ;
    PRE1(kk) = CM1{kk}(2,2) ./ sum(CM1{kk}(:,2)) ;
    F11(kk) = 2*PRE1(kk)*SEN1(kk) ./ (PRE1(kk) + SEN1(kk)) ;
end






idx = find(~isnan(ACC1+SEN1+SPE1+PRE1+F11)) ;
fprintf(['RMI -- remove NaN: ' num2str(length(idx)) '/' num2str(length(SEN1)) '\n']) ;
fprintf(['RMI: ACC = ' num2str(mean(ACC1(idx))) '+/-' num2str(std(ACC1(idx))) '\n']) ;
fprintf(['RMI: SEN of high-quality = ' num2str(mean(SEN1(idx)))...
    '+/-' num2str(std(SEN1(idx))) '\n']) ;
fprintf(['RMI: SPE of high-quality = ' num2str(mean(SPE1(idx)))...
    '+/-' num2str(std(SPE1(idx))) '\n']) ;
fprintf(['RMI: PRE of high-quality = ' num2str(mean(PRE1(idx)))...
    '+/-' num2str(std(PRE1(idx))) '\n']) ;
fprintf(['RMI: F1 of high-quality = ' num2str(mean(F11(idx)))...
    '+/-' num2str(std(F11(idx))) '\n']) ;


idx = find(isnan(ACC1+SEN1+SPE1+PRE1+F11)) ;
fprintf('REI1 -- replace NaN by 0\n') ;
ACC1q = ACC1 ;
SEN1q = SEN1 ;
SPE1q = SPE1 ;
PRE1q = PRE1 ;
F11q = F11 ;

ACC1q(idx) = 0 ;
SEN1q(idx) = 0 ;
SPE1q(idx) = 0 ;
PRE1q(idx) = 0 ;
F11q(idx) = 0 ;

fprintf(['RMI: ACC = ' num2str(mean(ACC1q)) '+/-' num2str(std(ACC1q)) '\n']) ;
fprintf(['RMI: SEN of high-quality = ' num2str(mean(SEN1q))...
    '+/-' num2str(std(SEN1q)) '\n']) ;
fprintf(['RMI: SPE of high-quality = ' num2str(mean(SPE1q))...
    '+/-' num2str(std(SPE1q)) '\n']) ;
fprintf(['RMI: PRE of high-quality = ' num2str(mean(PRE1q))...
    '+/-' num2str(std(PRE1q)) '\n']) ;
fprintf(['RMI: F1 of high-quality = ' num2str(mean(F11q))...
    '+/-' num2str(std(F11q)) '\n']) ;
