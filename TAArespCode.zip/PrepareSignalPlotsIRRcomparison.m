clear ; close all ;

addpath('/Users/hautiengwu/Dropbox/code/common') ;

CODEplace = '/Users/hautiengwu/Dropbox/___course/2025 sinica summer school/Matlab code' ;
addpath([CODEplace '/tool']) ;
addpath([CODEplace '/SST']) ;
addpath([CODEplace '/SAMD']) ;


folder = './database20251111';
ggg = dir([folder '/*.mat']) ;

scrsz = get(0,'ScreenSize') ;


QUALITYNAME = {'Bad', 'Moderate', 'Good'} ;
SLEEPNAME = {'Wake', 'REM', 'N1', 'N2', 'N3'} ;
APNEANAME = {'no-apnea' 'hypopnea' 'apnea'} ;


IRRerr = [] ;
RRerr = [] ;
QQQidx = 1 ;

DBIDX = 71: 90 ;


load('RESULT20260325.mat') ;

for index = DBIDX

    if exist(['Annotations-' ggg(index).name(1:end-4) '-' num2str(index) '.mat'])
        load(['Annotations-' ggg(index).name(1:end-4) '-' num2str(index)]) ;
    else
        annotations = -1*ones(1000, 1) ;
    end

    filename0 = ggg(index).name(1:end-4) ;

    % load raw data
    load([folder '/' ggg(index).name]);

    % get apnea label
    apnea = double(database.apnea_1blabel.signal) ; % 2hz
    apnea = median(reshape(apnea(1:120*floor(length(apnea)/120)),...
        120, floor(length(apnea)/120) ), 1) ;
    apnea = round(apnea) ; %1/60 hz (unit=epoch)


    % get sleep stage
    stage = double(database.sleep_stage.signal(60:60:end)) ; %1/30 hz (unit=epoch)

    genIMUresp ;
   
    stage = stage(1:SegNO) ;
    apnea = apnea(1:SegNO) ;
    apnea(apnea==1) = 2 ; % OSA+CSA
    apnea(apnea==2) = 2 ; % OSA+CSA
    apnea(apnea==3) = 1 ; % hypopnea
    REI = REI1onlyIMU{index} ;
    
    idx = find(~isnan(annotations)) ;
    stage = stage(idx) ;
    apnea = apnea(idx) ;
    REI = REI(idx) ;


    window_length = 60 ; % sec
    boundary_length = 0 ; % sec

    HQSEGIDX = find(annotations>0) ;

    t1 = tic ;
    for lll = 13 %:6:length(HQSEGIDX)

        waitbar(lll/length(HQSEGIDX), whandle, num2str(index)) ;
        sIDX = HQSEGIDX(lll) ;

        IDX = (sIDX-1) * (window_length - boundary_length) * Hz + 1 : ...
            ((sIDX-1) * (window_length - boundary_length) + window_length) * Hz ;

        FLOW = airflow(IDX) ;
        THO = thorax(IDX) ;  
        ABD = abdomen(IDX);  

        x = X(IDX, :) ;
        x(:, 1) = x(:, 1) - mean(x(:, 1)) ;
        x(:, 2) = x(:, 2) - mean(x(:, 2)) ;
        x(:, 3) = x(:, 3) - mean(x(:, 3)) ;
        x0 = X0(IDX, :) ;
        vm = signal(IDX) ;

        % generate figures to illustrate everything
        if 0
            genFigure2
            for kk = 1:4
                subplot(4,1,kk) ; xlim([0 60]) ; hold off
            end

            subplot(413)
            TITLE = [filename0 '--' num2str(sIDX) '/' num2str(SegNO) ':     '...
                QUALITYNAME{annotations(sIDX)+1} '     '...
                '     REI=' num2str(REI(sIDX)) ' -- '...
                SLEEPNAME{stage(sIDX)-10} '     '...
                APNEANAME{apnea(sIDX)+1} ] ;
            title(TITLE)

            filename = [num2str(apnea(sIDX)+1) '_' num2str(stage(sIDX)-10) '_'...
                num2str(annotations(sIDX)+1) '_' filename0 '_' num2str(sIDX)] ;
            exportgraphics(h1, [filename '.pdf'],...
                'ContentType', 'vector', 'BackgroundColor','none');
        end



        % apply SST to compare IF estimated from THO and IMU-resp


        IDX = (sIDX-1) * (window_length - boundary_length) * Hz + 1 - 70 : ...
            ((sIDX-1) * (window_length - boundary_length) + window_length) * Hz +70 ;

        FLOW = airflow(IDX) ;
        THO = thorax(IDX) ;
        ABD = abdomen(IDX);
        vm = signal(IDX) ;

        
        WindowLength = Hz*5*6+1 ;
        [~, ~, tfrsqx, ~, tfrsqtic, ~] = ConceFT_sqSTFT_C(vm, 0, ...
            0.25, 1e-4, 1, WindowLength, 1, 6, 1, 1, 0) ;

        tfrsqx = tfrsqx(:, 71: end-70) ; tfrsqx0 = tfrsqx ;
        idx = tfrsqtic*Hz < 0.08 ; 
        tfrsqx(idx, :) = 0 ;

        % estimate the rough mean RR
        xi = Hz * (1:length(vm)/2) / length(vm) ;
        tmp = abs(fft(vm)) ;
        idx = find(xi>0.08 & xi<0.6) ;
        [~, idx2] = max(tmp(idx)) ;
        xi0 = xi(idx(idx2)) ;

        % determine the band for curve extraction
        idx = find(tfrsqtic*Hz < xi0 + 0.2 & tfrsqtic*Hz > max(0, xi0 - 0.2)) ;
        [c] = CurveExt_M(abs(tfrsqx(idx, :))', 0.05) ; % 0.2 before.
        c = c - 1 + idx(1) ;
        IMUIRR = tfrsqtic(c) * Hz;

        [~, ~, tfrsq2, ~, tfrsqtic, ~] = ConceFT_sqSTFT_C(THO', 0, ...
            0.25, 1e-4, 1, WindowLength, 1, 6, 1, 1, 0) ;

        tfrsq2 = tfrsq2(:, 71: end-70) ; tfrsq20 = tfrsq2 ;
        idx = tfrsqtic*Hz < 0.08 ; 
        tfrsq2(idx, :) = 0 ;

        % estimate the rough mean RR
        xi = Hz * (1:length(vm)/2) / length(vm) ;
        tmp = abs(fft(THO)) ;
        idx = find(xi>0.08 & xi<0.6) ;
        [~, idx2] = max(tmp(idx)) ;
        xi0 = xi(idx(idx2)) ;

        % determine the band for curve extraction
        idx = find(tfrsqtic*Hz < xi0 + 0.2 & tfrsqtic*Hz > max(0, xi0 - 0.2)) ;
        [c] = CurveExt_M(abs(tfrsq2(idx, :))', 0.05) ; % 0.2 before.
        c = c - 1 + idx(1) ;
        THOIRR = tfrsqtic(c) * Hz;


        IRRerr(QQQidx) = sqrt(mean((THOIRR - IMUIRR).^2)) ;
        IRRerrNRMSE(QQQidx) = sqrt(mean((THOIRR - IMUIRR).^2)) ./ sqrt(mean(THOIRR.^2)) ;
        RRerr(QQQidx) = mean(THOIRR) - mean(IMUIRR) ;
        STAGEerr(QQQidx) = stage(lll) ;
        APNEAerr(QQQidx) = apnea(lll) ;
        REIerr(QQQidx) = REI(lll) ;
        QQQidx = QQQidx + 1 ;

        time = (1:length(IMUIRR)) / Hz ;

        if 1

            h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ;
            
            subplot_tight(3, 2, 1, [0.042 0.05]) ; yticks('auto');
            MM = quantile(abs(vm(71:end-70)), .99) ;
            plot(time, MM * THO(71:end-70)./quantile(abs(THO(71:end-70)), .99),...
                'color', [.7 .7 .7], 'linewidth', 2) ; hold on ;
            plot(time, vm(71:end-70), 'k', 'linewidth', 2) ; 
            set(gca,'fontsize', 18) ; axis tight ;
            MM = ceil(MM/10) * 10 ; ylim([-MM MM]) ;
            legend('THO', 'TAA-resp') ; hold off ;

            subplot_tight(3, 2, 2, [0.042 0.05]) ; yticks('auto');
            plot(time, THOIRR, 'color', [.7 .7 .7], 'linewidth', 2) ; hold on ;
            plot(time, IMUIRR, 'k', 'linewidth', 2) ; 
            legend('from THO', 'from TAA-resp') ; set(gca,'fontsize', 18) ; 
            xi0 = ceil(xi0*10) / 10 ;
            axis tight ; ylim([0.05 xi0+0.2]) ; hold off ;

            subplot_tight(3, 2, 3, [0.042 0.05]) ; 
            imageSQ(time, tfrsqtic*Hz, abs(tfrsqx0), .995) ;
            ylabel('frequency (Hz)') ; set(gca,'fontsize', 18) ;
            ylim([0 0.8]) ;

            subplot_tight(3, 2, 5, [0.042 0.05]) ; 
            imageSQ(time, tfrsqtic*Hz, abs(tfrsq20), .995) ;
            ylabel('frequency (Hz)') ; set(gca,'fontsize', 18) ;
            ylim([0 0.8]) ; xlabel('Time (s)') ;

            subplot_tight(3, 2, 4, [0.042 0.05]) ; 
            imageSQ(time, tfrsqtic*Hz, abs(tfrsqx0), .995) ;
            ylabel('frequency (Hz)') ; set(gca,'fontsize', 18) ; hold on ;
            plot(time, IMUIRR, 'r', 'linewidth', 3) ; 
            ylim([0 0.8]) ; hold off ;

            subplot_tight(3, 2, 6, [0.042 0.05]) ; 
            imageSQ(time, tfrsqtic*Hz, abs(tfrsq20), .995) ;
            ylabel('frequency (Hz)') ; set(gca,'fontsize', 18) ; hold on ;
            plot(time, THOIRR, 'r', 'linewidth', 3) ; xlabel('Time (s)') ;
            ylim([0 0.8]) ; colormap(1-gray) ; hold off ;

            if annotations(sIDX) == 2
                filename = ['GOOD_' num2str(index) '_' num2str(lll) '_' ...
                    num2str(IRRerr(QQQidx-1)) '_'...
                    num2str(apnea(sIDX)+1) '_' num2str(stage(sIDX)-10) '_'...
                    filename0 '_' num2str(sIDX) 'TFR'] ;
            else
                filename = ['Moderate_' num2str(index) '_' num2str(lll) '_' ...
                    num2str(IRRerr(QQQidx-1)) '_'...
                    num2str(apnea(sIDX)+1) '_' num2str(stage(sIDX)-10) '_'...
                    filename0 '_' num2str(sIDX) 'TFR'] ;
            end
            
            exportgraphics(h1, [filename '.pdf'],...
                'ContentType', 'vector', 'BackgroundColor','none') ;   

            close all

        end
    end
    
    toc(t1) ;

end


fprintf('IRR RMSE:\n') ;
disp([mean(IRRerr) std(IRRerr)]) ;
fprintf('RR RMSE:\n') ;
disp([mean(RRerr) std(RRerr)]) ;


idx = find(STAGEerr == 12 | STAGEerr == 14 | STAGEerr == 15) ;
fprintf('Good sleep: IRR RMSE:\n') ;
disp([mean(IRRerr(idx)) std(IRRerr(idx))]) ;
fprintf('RR RMSE:\n') ;
disp([mean(RRerr(idx)) std(RRerr(idx))]) ;

idx2 = find(STAGEerr == 11 | STAGEerr == 13) ;
disp([mean(IRRerr(idx2)) std(IRRerr(idx2))]) ;
p = ranksum(IRRerr(idx), IRRerr(idx2))
disp([mean(RRerr(idx2)) std(RRerr(idx2))]) ;
p = ranksum(RRerr(idx), RRerr(idx2))


idx = find(APNEAerr == 0) ;
fprintf('No apnea: IRR RMSE:\n') ;
disp([mean(IRRerr(idx)) std(IRRerr(idx))]) ;
fprintf('RR RMSE:\n') ;
disp([mean(RRerr(idx)) std(RRerr(idx))]) ;

idx2 = find(APNEAerr == 1) ;
disp([mean(IRRerr(idx2)) std(IRRerr(idx2))]) ;
p = ranksum(IRRerr(idx), IRRerr(idx2))
disp([mean(RRerr(idx2)) std(RRerr(idx2))]) ;
p = ranksum(RRerr(idx), RRerr(idx2))

idx = find(REIerr > 0.5) ;
fprintf('High REI: IRR RMSE:\n') ;
disp([mean(IRRerr(idx)) std(IRRerr(idx))]) ;
fprintf('RR RMSE:\n') ;
disp([mean(RRerr(idx)) std(RRerr(idx))]) ;