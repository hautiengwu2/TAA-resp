function [OUTPUT, time_ext] = warpsignal(INPUT, time, phi)

resample_time = 0.1;
time_ext = time(1):resample_time*(time(2) - time(1)): phi(end) ;

phi_inverse_ext = interp1(phi, time, time_ext, 'linear', 'extrap');

OUTPUT = interp1(time, INPUT, phi_inverse_ext, 'linear', 'extrap'); % resample y according to phi^-1

% INPUT: f(t), which is g(\phi(t))
% time: original time of f(t), PHI0: estimated \phi(t)
% OUTPUT: g(t)

% the initial value \phi(0) should be shifted to 0 to calculate 
% the dilation factor Qf
% Qf = (time(end)-time(1)) / (PHI0(end)-PHI0(1)) ;
% 
% % this is the inverse-phase for warpping (pchip before)
% PHIinv = interp1(PHI0, time, linspace(PHI0(1), PHI0(end), ceil(length(time)/Qf)), 'linear', 'extrap') ;
% 
% % warp OC using PPG-IHR 
% OUTPUT = interp1(time, INPUT, PHIinv, 'pchip', 'extrap') ;
% 
% 
% 
% % direct dilate -- no need to handle the initial value
% %PHI = Qf * PHI0 ;
% % this is the associated sampling rate after warpping 
% UWHz = 1./(time(2)-time(1)) ;
% % this is associated with the time described by the phase \phi(t)
% UWtime = [1:length(OUTPUT)] / UWHz ;
