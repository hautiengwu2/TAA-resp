function [AUC, L, R, optthreshold, a, b, tidx] = evalROC(T, R, PLOT)
%%% evaluate the ROC curve
% T= true label, 0 or 1
% R= score

%[a, b, c] = roc(T, R) ;
%% a is false positive rate, b is true positive rate
[a, b, c, auc, tidx] = perfcurve(T, R, 1, 'NBOOT', 1000);
[~, idx] = max(b(:,1) - a(:,1)) ;
tidx = round(100*[a(idx) b(idx)])/100 ;
optthreshold = c(idx) ;


if PLOT
    hold off ;
    plot([0,1], [0,1], 'color', [.8 .8 .8], 'linewidth', 1.2) ;
    set(gca, 'fontsize', 18); axis equal ; axis tight;
    xlabel('False Positive Rate'); ylabel('True Positive Rate');
    hold on ;
    plot(a(:,1), b(:,1), 'color', [.3 .3 .3], 'linewidth', 1.2) ;
    plot(tidx(1), tidx(2), 'ko', 'linewidth', 2, 'MarkerSize', 20) ;
    text(tidx(1)+.02, tidx(2)-.05, ['Sensitivity = ',num2str(tidx(2))], 'fontsize', 20)
    text(tidx(1)+.02, tidx(2)-.1, ['Specificity = ',num2str(1 - tidx(1))], 'fontsize', 20)
    legend('Random Classifier','ROC Curve', 'Cut-off Point', 'location', 'southeast')
    plot(a(:,1), b(:,1), '.', 'color', [.1 .1 .1], 'linewidth', 2) ;
end
    
fprintf(['\tAUC = ',num2str(auc(1)),' CI = [',num2str(auc(2)),',',num2str(auc(3)),']\n']) ;


AUC = auc(1) ;
L = auc(2) ;
R = auc(3) ;
end

