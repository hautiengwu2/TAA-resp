function [chi2stat, df, p] = chi2cont(total, success)

failure = total - success;

% Observed table (2 × k)
obs = [success; failure];

% Expected counts
row_sums = sum(obs, 2);
col_sums = sum(obs, 1);
N = sum(obs(:));

expected = (row_sums * col_sums) / N;

% Chi-square statistic
chi2stat = sum((obs - expected).^2 ./ expected, 'all');

% Degrees of freedom
df = (size(obs,1)-1) * (size(obs,2)-1);

% p-value
p = 1 - chi2cdf(chi2stat, df);