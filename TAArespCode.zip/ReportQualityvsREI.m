QUALITYNAME = {'Bad', 'Moderate', 'Good'} ;

forREI1{1} = ALLREI1(ALLLABEL==0) ;
forREI1{2} = ALLREI1(ALLLABEL==1) ;
forREI1{3} = ALLREI1(ALLLABEL==2) ;
forREI1{1} = forREI1{1}(~isnan(forREI1{1})) ;
forREI1{2} = forREI1{2}(~isnan(forREI1{2})) ;
forREI1{3} = forREI1{3}(~isnan(forREI1{3})) ;

validREI1 = [forREI1{1}; forREI1{2}; forREI1{3}] ;
if isempty(validREI1)
    ymax = 1 ;
else
    ymax = 1.2*quantile(validREI1, .99) ;
    if ~isfinite(ymax) || ymax <= 0
        ymax = max(validREI1) ;
    end
    if ~isfinite(ymax) || ymax <= 0
        ymax = 1 ;
    end
end

h2 = figure('Position',[1 scrsz(4) scrsz(3)*3/5 scrsz(4)/2]) ;
[h,L,MX,MED] = violin(forREI1, 'facealpha', 0.2, 'bw', 0.02) ;
ylim([0 ymax])
set(gca,'TickLabelInterpreter', 'latex');
set(gca,'xtick',1:length(QUALITYNAME))
set(gca,'xticklabel', QUALITYNAME) ;
set(gca,'fontsize', 20) ;
ylabel('REI', 'interpreter', 'latex')
exportgraphics(h2, 'REI.pdf', 'ContentType', 'vector', 'BackgroundColor','none');

fprintf('mean REI of 3 groups\n') ;
disp(MX)

fprintf('SD REI of 3 groups\n') ;
disp([std(forREI1{1}) std(forREI1{2}) std(forREI1{3})])

fprintf('median REI of 3 groups\n') ;
disp(MED)

fprintf('MAD REI of 3 groups\n') ;
disp([mad(forREI1{1}) mad(forREI1{2}) mad(forREI1{3})])
