clear ; close all ;

CODEplace = '/Users/admin/desktop/Research/MATLAB/code' ;
addpath([CODEplace '/tool']) ;
addpath([CODEplace '/SST']) ;
addpath([CODEplace '/SAMD']) ;


codeshare = '/Users/admin/desktop/Research/IMU/codeShare' ;
addpath(codeshare)

% this is the folder of some example datasets
folder = '/Users/admin/desktop/Research/IMU/database20251111';
ggg = dir([folder '/*.mat']) ;

scrsz = get(0,'ScreenSize') ;

% these are cases having experts' labels
DBIDX = 1 ; %setdiff(60: 100, [65 69]) ;


flag1 = 0 ; flag2 = 0 ;

% randomly select 500 directions to evaluate REI
S2P = randn(3, 500) ;
for jj = 1: 500
    S2P(:, jj) = S2P(:, jj) ./ norm(S2P(:, jj)) ;
end


Wn = [0.1 1]/(5/2);
[bbb, aaa] = butter(4, Wn, 'bandpass');

global plotTFR ;
plotTFR = 0 ;

plotSIGNAL = 1 ;

if plotSIGNAL
    global h3 ; global h0 ;
    h0 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)/4]) ;
    h1 = figure('Position',[1 scrsz(4) scrsz(3)*0.3 scrsz(4)]) ;
    h2 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)/2]) ;
    h3 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)*3/4]) ;
end



% if want to generate figures for paper, use plotSIGNAL + DBIDX
for index = DBIDX %1:length(ggg)

    t1 = tic ;
    disp([index length(ggg)])
    load([folder '/' ggg(index).name]);


    if exist(['/Users/admin/Desktop/Research/IMU/codeShare/annotations/Annotations-' ggg(index).name(1:end-4) '-' num2str(index) '.mat'])
        fprintf(['QQ--find annotations of ' num2str(index) '--' ggg(index).name(1:end-4) '\n']) ;
        load(['/Users/admin/Desktop/Research/IMU/codeShare/annotations/Annotations-' ggg(index).name(1:end-4) '-' num2str(index)]) ;
        disp(unique(annotations(find(~isnan(annotations))))')
    else
        annotations = nan(1000, 1) ;
    end


    % TipTraQ IMU = 50 Hz
    % clean up each channel via cumsum
    x0 = database.imu.x.signal ; x0 = x0 - mean(x0) ;
    trend = medfilt1(x0, 10*double(database.imu.y.fs)) ;
    x1 = x0 - trend ;
    x2 = cumsum(x1) / double(database.imu.y.fs) ;
    trend = medfilt1(x2, 10*double(database.imu.y.fs)) ;
    x3 = x2 - trend ;
    x = x3(1: 10*floor(length(x2)/10)) ;
    xaxis = x(1:10:end) ; % reduce to 5Hz
    x0axis = database.imu.x.signal(1:10:end) ;

    x0 = database.imu.y.signal ; x0 = x0 - mean(x0) ;
    trend = medfilt1(x0, 10*double(database.imu.y.fs)) ;
    x1 = x0 - trend ;
    x2 = cumsum(x1) / double(database.imu.y.fs) ;
    trend = medfilt1(x2, 10*double(database.imu.y.fs)) ;
    x3 = x2 - trend ;
    x = x3(1: 10*floor(length(x2)/10)) ;
    yaxis = x(1:10:end) ; % reduce to 5Hz
    y0axis = database.imu.y.signal(1:10:end) ;

    x0 = database.imu.z.signal ; x0 = x0 - mean(x0) ;
    trend = medfilt1(x0, 10*double(database.imu.y.fs)) ;
    x1 = x0 - trend ;
    x2 = cumsum(x1) / double(database.imu.y.fs) ;
    trend = medfilt1(x2, 10*double(database.imu.y.fs)) ;
    x3 = x2 - trend ;
    x = x3(1: 10*floor(length(x2)/10)) ;
    zaxis = x(1:10:end) ; % reduce to 5Hz
    z0axis = database.imu.z.signal(1:10:end) ;

    % remove outliers
    xaxis(abs(xaxis)>500) = 0 ;
    yaxis(abs(yaxis)>500) = 0 ;
    zaxis(abs(zaxis)>500) = 0 ;

    % the IMU signal
    X = [xaxis ; yaxis ; zaxis]' ;
    X0 = [x0axis ; y0axis ; z0axis]' ;

    % get ground truth resp signals
    airflow = database.airflow.signal ; % true signal
    airflow = airflow(1:20:end) ; % reduce to 5Hz - original 100hz

    thorax = database.thorax.signal ; % true signal
    thorax = thorax(1:20:end) ; % reduce to 5Hz - original 100hz

    abdomen = database.abdomen.signal ; % true signal
    abdomen = abdomen(1:20:end) ; % reduce to 5Hz - original 100hz

    Hz = 5 ;

    % each window is 60s long, with overlap 30s
    window_length = 60 ; % sec
    boundary_length = 0 ; % sec
    SEGNO = floor( (length(xaxis) / 5 - boundary_length) / window_length) ;

    
    QIlist = find(annotations == 1) ;

    if ~isempty(QIlist)
    for qqq = 1: length(QIlist)

        sIDX = QIlist(qqq) ;

        IDX = (sIDX-1) * (window_length - boundary_length) * Hz + 1 : ...
            ((sIDX-1) * (window_length - boundary_length) + window_length) * Hz ;

        eIDX = IDX(1)-50 : IDX(end)+50 ;
        eIDX(eIDX<1) = 1 ;
        eIDX(eIDX>length(X(:,1))) = length(X(:,1)) ;

        % extended one to avoid boundary effect
        ex = X(eIDX, :) ;
        ex(:, 1) = ex(:, 1) - mean(x(:, 1)) ;
        ex(:, 2) = ex(:, 2) - mean(x(:, 2)) ;
        ex(:, 3) = ex(:, 3) - mean(x(:, 3)) ;

        % normal one
        x = X(IDX, :) ;
        x(:, 1) = x(:, 1) - mean(x(:, 1)) ;
        x(:, 2) = x(:, 2) - mean(x(:, 2)) ;
        x(:, 3) = x(:, 3) - mean(x(:, 3)) ;
        x0 = X0(IDX, :) ;

        FLOW = airflow(IDX) ;
        THO = thorax(IDX) ; THO = THO - mean(THO) ;
        ABD = abdomen(IDX); ABD = ABD - mean(ABD) ;


        % determine IMU-resp
        xi = Hz * (0:window_length*Hz/2-1) / (window_length*Hz) ;
        idx = find(xi > 0.1 & xi < 0.4) ;
        xhat = zeros(length(idx), 3) ;
        for ss = 1: 3
            tmp = fft(x(:, ss)) ./ norm(x(:, ss)) ; xhat(:, ss) = tmp(idx) ;
        end

        % evm = the optimal resp from linear combination of x,y,z WITHOUT THO
        tmp = max(abs(xhat * S2P), [], 1) ;
        [~, idx] = max(tmp) ;

        % construct the extended optimal resp
        evm0 = ex * S2P(:, idx(1)) ;
        evm = filtfilt(bbb, aaa, evm0) ;
        vm0 = x * S2P(:, idx(1)) ;
        vm = filtfilt(bbb, aaa, vm0) ;


        % evaluate REI0 (imperfect version without unwarping)
        xhat = fft(vm, length(vm)*3) ;
        xi = Hz * (0:length(xhat)/2-1) / length(xhat) ;
        idx = find(xi > 0.1 & xi < 0.4) ;
        [~, tmp] = max(abs(xhat(idx))) ;
        idx = idx(1) + tmp - 1 ;
        idx1 = xi > xi(idx)-0.05 & xi < xi(idx)+0.05 ;
        idx2 = xi > 0.05 & xi < 1 ;
        REI0 = sum(abs(xhat(idx1)).^2) ./ sum(abs(xhat(idx2)).^2) ;

        if REI0 > 1
            REI0 = 0 ;
        end

        % Added for reproducibility/debugging: some annotated segments do not
        % pass the unwarping gate below, so pre-initialize these variables
        % instead of letting later plotting code error on undefined OUTPUT/UWHz.
        OUTPUT = [] ;
        UWHz = [] ;

        % evaluate REI using SST+unwarping
        if REI0 > 0.2
            [AM, PHI, IRR] = generatePhase(evm, Hz) ;

            % if less than 4 cycles detected in 60 seconds, cannot be good!
            if PHI(end) > 4
                [OUTPUT, time_ext] = warpsignal(vm, (1:length(vm))'/Hz, PHI) ;
                UWHz = round(1./ (time_ext(2)-time_ext(1))) ;
                xhat = fft(OUTPUT, length(OUTPUT)*3) ;
                xi = UWHz * (1:length(xhat)/2) / length(xhat) ;
                idx1 = find(xi > 0.9 & xi < 1.1) ;
                idx2 = find(xi > 0.1 & xi < 3) ;
                REI1 = sum(abs(xhat(idx1)).^2) ./ sum(abs(xhat(idx2)).^2) ;
                REI1 = round(1000*REI1)/1000 ;
                 
                if isempty(REI1) ; REI1 = 0 ; end
            else
                REI1 = 0 ;  
            end
        else
            REI1 = 0 ;  
        end


        % This block now runs only when unwarping succeeded and OUTPUT/UWHz
        % were actually created for the current segment.
        if ~isempty(OUTPUT) && ~isempty(UWHz)
            if ~exist('h0', 'var') || isempty(h0) || ~isgraphics(h0, 'figure')
                h0 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)/4]) ;
            else
                figure(h0) ;
            end
            plot((1:length(vm))/5, vm, 'k', 'linewidth', 5) ;
            set(gca,'fontsize', 28) ; axis tight ;
            text(1,100,'(b)','fontsize', 46) ;
            exportgraphics(gcf, 'vm_signal.pdf', 'ContentType', 'vector',...
                'BackgroundColor','none');
            
            plot((1:length(vm))/5, vm0, 'k', 'linewidth', 5) ;
            set(gca,'fontsize', 28) ; axis tight ;
            text(1,100,'(a)','fontsize', 46) ;
            exportgraphics(gcf, 'vm0_signal.pdf', 'ContentType', 'vector',...
                'BackgroundColor','none');

            plot((1:length(OUTPUT))/UWHz, OUTPUT, 'k', 'linewidth', 5) ;
            set(gca,'fontsize', 28) ;  
            text(0.2,100,'(e)','fontsize', 46) ; axis tight ;
            exportgraphics(gcf, 'vm_unwrap.pdf', 'ContentType', 'vector',...
                'BackgroundColor','none');
            %pause
        end



        % this is Figure 3
        if 1 %REI1 < 0.45
        if ~exist('h1', 'var') || isempty(h1) || ~isgraphics(h1, 'figure')
            h1 = figure('Position',[1 scrsz(4) scrsz(3)*0.3 scrsz(4)]) ;
        else
            figure(h1)
        end
        subplot(411) ; hold off
        plot((1:length(vm))/5, x0(:,1) - mean(x0(:,1))+2*std(x0(:,1)), 'k', 'linewidth', 2) ; hold on ;
        plot((1:length(vm))/5, x0(:,2) - mean(x0(:,2)), 'r', 'linewidth', 2)
        plot((1:length(vm))/5, x0(:,3) - mean(x0(:,3))-2*std(x0(:,1)), 'b', 'linewidth', 2)
        set(gca,'fontsize', 20) ;
        legend('a_x', 'a_y', 'a_z') ;  xlim([0 40]) ; axis tight

        subplot(412) ; hold off
        plot((1:length(vm))/5, x(:,1), 'k', 'linewidth', 2) ; hold on ;
        plot((1:length(vm))/5, x(:,2), 'r', 'linewidth', 2)
        plot((1:length(vm))/5, x(:,3), 'b', 'linewidth', 2)
        set(gca,'fontsize', 20) ;
        legend('v_x', 'v_y', 'v_z') ;  xlim([0 40]) ;

        subplot(413) ; hold off
        plot((1:length(vm))/5, quantile(abs(vm), .99) * THO ./ quantile(abs(THO), .99), ...
            'color', [.7 .7 .7], 'linewidth', 2) ; hold on ;
        plot((1:length(vm))/5, vm, 'k', 'linewidth', 3) ;
        set(gca,'fontsize', 20) ; xlim([0 40]) ;

        subplot(414) ; hold off
        plot((1:length(vm))/5, quantile(abs(FLOW), .99) * THO ./ quantile(abs(THO), .99), ...
            'color', [.7 .7 .7], 'linewidth', 2) ; hold on ;
        plot((1:length(vm))/5, FLOW, 'r', 'linewidth', 2) ;
        xlabel('Time (s)') ; set(gca,'fontsize', 20) ; xlim([0 40]) ;


        disp(REI1) ;
        TITLE = [num2str(index) '_' num2str(sIDX) '_' ...
            num2str(round(100*REI1)/100)] ;
        exportgraphics(gcf, ['Signal' TITLE '.pdf'],...
            'ContentType', 'vector', 'BackgroundColor','none') ;


        % This figure depends on the unwarped signal, so skip it cleanly when
        % the current segment does not satisfy the REI/phase checks above.
        if ~isempty(OUTPUT) && ~isempty(UWHz)
            if ~exist('h2', 'var') || isempty(h2) || ~isgraphics(h2, 'figure')
                h2 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)/2]) ;
            else
                figure(h2)
            end
            subplot(2,3,[1 2]) ; hold off
            plot((1:length(vm))/5, quantile(abs(vm), .99) * THO ./ quantile(abs(THO), .99), ...
                'color', [.7 .7 .7], 'linewidth', 2) ; hold on ;
            plot((1:length(vm))/5, vm, 'k', 'linewidth', 4) ; 
            set(gca,'fontsize', 22) ;  axis tight ; 
            ylabel('$r$', 'Interpreter', 'latex')

            xhat = fft(vm, length(vm)*3) / Hz ;
            xi = Hz * (1:length(xhat)/2) / length(xhat) ;

            subplot(2,3,3) ; hold off
            plot(xi, abs(xhat(2:floor(end/2)+1)), 'k', 'linewidth', 2) ; hold on ;
            set(gca,'fontsize', 22) ; xlim([0.01 0.8]) ;
            ylabel('$|\hat{r}|$', 'Interpreter', 'latex')
            
            subplot(2,3,[4 5]) ; hold off
            plot((1:length(OUTPUT))/UWHz, OUTPUT, 'b', 'linewidth', 4) ; hold on ;
            set(gca,'fontsize', 22) ; axis tight ; xlabel('Time (s)') ;
            ylabel('$z$', 'Interpreter', 'latex')
            
            xhat = fft(OUTPUT, length(OUTPUT)*3) / UWHz ;
            xi = UWHz * (1:length(xhat)/2) / length(xhat) ;
            

            subplot(2,3,6) ; hold off
            plot(xi, abs(xhat(2:floor(end/2)+1)), 'b', 'linewidth', 2) ; hold on ;
            xlabel('Freq (Hz)') ; set(gca,'fontsize', 22) ; xlim([0.1 2.5]) ;
            ylabel('$|\hat{z}|$', 'Interpreter', 'latex')
            
            exportgraphics(gcf, ['Spec' TITLE '.pdf'],...
                'ContentType', 'vector', 'BackgroundColor','none') ;
        end
        %pause(1)

        end

    end
    end
end
