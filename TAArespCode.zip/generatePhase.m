function [AM, PHI, IRR] = generatePhase(SIG, Hz)
global plotTFR ;

WindowLength = Hz*5*6+1 ;
[~, ~, tfrsqx, ~, tfrsqtic, ~] = ConceFT_sqSTFT_C(SIG, 0, ...
    0.25, 1e-4, 1, WindowLength, 1, 6, 1, 1, 0) ;

tfrsqx = tfrsqx(:, 51: end-50) ;
SIG = SIG(51: end-50) ;

idx = tfrsqtic*Hz < 0.08 ;
tfrsqx(idx, :) = 0 ;

idx = find(tfrsqtic*Hz < 0.4 & tfrsqtic*Hz > 0.08) ;
[c] = CurveExt_M(abs(tfrsqx(idx, :))', 0.05) ; % 0.2 before. 
c = c - 1 + idx(1) ;
IRR = tfrsqtic(c) * Hz;


if plotTFR
    scrsz = get(0,'ScreenSize') ;
    global h0 ;
    figure(h0) ;
    ax(1) = subplot(311) ; hold off
    plot((1:length(SIG))/Hz, SIG, 'b', 'linewidth', 2) ; hold on ;
    set(gca, 'fontsize', 18) ;

    ax(2) = subplot(312) ; hold off
    imageSQ((1:length(SIG))/Hz, tfrsqtic*Hz, abs(tfrsqx), .995) ;
    axis([-inf inf 0 0.6]) ;
    set(gca, 'fontsize', 18) ;

    ax(3) = subplot(313) ; hold off
    imageSQ((1:length(SIG))/Hz, tfrsqtic*Hz, abs(tfrsqx), .995) ;
    hold on;
    plot((1:length(SIG))/Hz, tfrsqtic(c)*Hz, 'r', 'linewidth', 3);
    colormap(1-gray) ;
    axis([-inf inf 0 0.6]) ;
    set(gca, 'fontsize', 18) ; xlabel('Time (s)')

    linkaxes(ax, 'x') ;

end






[h, ~, ~] = hermf(WindowLength, 1, 6) ;
Band = 0.05 ;
[recon] = Recon_sqSTFT_v2(tfrsqx, tfrsqtic, Hz, c, Band, h((WindowLength+1)/2)) ;

AM = abs(recon) ;
PHI = phase(recon ./ max(0.1, AM)) / 2 / pi ; % changed from phase() to angle()

% this is for subplots in Figure 1
%if 1
    %global h3 ; figure(h3) ;
    %imageSQ((1:length(SIG))/Hz, tfrsqtic*Hz, abs(tfrsqx), .995) ;
    %hold on;
    %plot((1:length(SIG))/Hz, tfrsqtic(c)*Hz, 'r', 'linewidth', 3);
    %colormap(1-gray) ; set(gca,'fontsize', 28) ;  
    %axis([-inf inf 0 0.8]) ; ylabel('Freq (Hz)')
    %text(1,0.05,'(c)','fontsize', 46) ;
    %exportgraphics(h3, 'vm_TFR.pdf', 'ContentType', 'vector',...
         %'BackgroundColor','none') ;

    %global h0 ; figure(h0) ;
    %plot((1:length(recon))/5, mod(PHI, 1), 'k', 'linewidth', 5) ;
    %set(gca,'fontsize', 28) ;
    %text(0.2,0.1,'(d)','fontsize', 46) ;
    %exportgraphics(h0, 'vm_PHI.pdf', 'ContentType', 'vector',...
        %'BackgroundColor','none');
%end

global h3 ;
if ~isempty(h3) && isgraphics(h3, 'figure')
    figure(h3) ;
    imageSQ((1:length(SIG))/Hz, tfrsqtic*Hz, abs(tfrsqx), .995) ;
    colormap(1-gray) ; set(gca,'fontsize', 28) ;
    axis([-inf inf 0 0.8]) ; ylabel('Freq (Hz)')
    text(1,0.05,'(c)','fontsize', 46) ;
    exportgraphics(h3, 'vm_TFR.pdf', 'ContentType', 'vector',...
         'BackgroundColor','none') ;
end

global h0 ;
if ~isempty(h0) && isgraphics(h0, 'figure')
    figure(h0) ;
    plot((1:length(recon))/5, mod(PHI, 1), 'k', 'linewidth', 5) ;
    set(gca,'fontsize', 28) ;
    text(0.2,0.1,'(d)','fontsize', 46) ;
    exportgraphics(h0, 'vm_PHI.pdf', 'ContentType', 'vector',...
        'BackgroundColor','none') ;
end



% force PHI to be strictly monotonic!
PHI = sort(PHI, 'ascend') ;
idx = find(diff(PHI)==0) ;
if ~isempty(idx)
    PHI(idx) = PHI(idx) + 0.01*randn(size(PHI(idx))) ;
    PHI = sort(PHI, 'ascend') ;
end
