% the data structure should be modified to the database you have

% thorax signal
thorax = database.thorax.signal ; % true signal
thorax = thorax(1:20:end) ; % reduce to 5Hz - original 100hz

airflow = database.airflow.signal ;
airflow = airflow(1:20:end) ;

abdomen = database.abdomen.signal ; % true signal
abdomen = abdomen(1:20:end) ;


% TipTraQ IMU = 50 Hz
% clean up each channel via cumsum
x0 = database.imu.x.signal ; x0 = x0 - mean(x0) ;
trend = medfilt1(x0, 10*double(database.imu.y.fs)) ;
x1 = x0 - trend ;
x2 = cumsum(x1) / double(database.imu.y.fs) ;
trend = medfilt1(x2, 10*double(database.imu.y.fs)) ;
x3 = x2 - trend ;
x = x3(1: 10*floor(length(x2)/10)) ;
xaxis = x(1:10:end) ; % reduce to 5Hz
x0axis = database.imu.x.signal(1:10:end) ;

x0 = database.imu.y.signal ; x0 = x0 - mean(x0) ;
trend = medfilt1(x0, 10*double(database.imu.y.fs)) ;
x1 = x0 - trend ;
x2 = cumsum(x1) / double(database.imu.y.fs) ;
trend = medfilt1(x2, 10*double(database.imu.y.fs)) ;
x3 = x2 - trend ;
x = x3(1: 10*floor(length(x2)/10)) ;
yaxis = x(1:10:end) ; % reduce to 5Hz
y0axis = database.imu.y.signal(1:10:end) ;

x0 = database.imu.z.signal ; x0 = x0 - mean(x0) ;
trend = medfilt1(x0, 10*double(database.imu.y.fs)) ;
x1 = x0 - trend ;
x2 = cumsum(x1) / double(database.imu.y.fs) ;
trend = medfilt1(x2, 10*double(database.imu.y.fs)) ;
x3 = x2 - trend ;
x = x3(1: 10*floor(length(x2)/10)) ;
zaxis = x(1:10:end) ; % reduce to 5Hz
z0axis = database.imu.z.signal(1:10:end) ;


% remove outliers
xaxis(abs(xaxis)>500) = 0 ;
yaxis(abs(yaxis)>500) = 0 ;
zaxis(abs(zaxis)>500) = 0 ;


% the IMU signal
X = [xaxis ; yaxis ; zaxis]' ;
X0 = [x0axis ; y0axis ; z0axis]' ;




Hz = 5 ;


% this is the display/annotation window length
ViewLen = 1 ; % unit=min
SegLEN = ViewLen*60*Hz ;
SegNO = floor(length(thorax) / SegLEN) ;



% random spherical samples
initstate(1)
S2P = randn(3, 500) ;
for jj = 1: 500
    S2P(:, jj) = S2P(:, jj) ./ norm(S2P(:, jj)) ;
end


% prepare BPF
Wn = [0.1 1]/(5/2);
[bbb, aaa] = butter(4, Wn, 'bandpass');





signal = zeros(size(thorax')) ;

% correct rotation
for sIDX = 1: SegNO
    whandle = waitbar(sIDX/SegNO) ;
    IDX0 = (sIDX-1) * SegLEN + 1: sIDX * SegLEN ;

    x = X(IDX0, :) ;
    x(:, 1) = x(:, 1) - mean(x(:, 1)) ;
    x(:, 2) = x(:, 2) - mean(x(:, 2)) ;
    x(:, 3) = x(:, 3) - mean(x(:, 3)) ;


    % determine rotation via REI
    xi = Hz * (0:SegLEN*Hz/2-1) / (SegLEN*Hz) ;
    idx = find(xi > 0.1 & xi < 0.4) ;
    xhat = zeros(length(idx), 3) ;
    for ss = 1: 3
        tmp = fft(x(:, ss)) ./ norm(x(:, ss)) ; xhat(:, ss) = tmp(idx) ;
    end

    % xRR = the optimal resp from linear combination of x,y,z WITHOUT THO
    tmp = max(abs(xhat * S2P), [], 1) ;
    [~, idx] = max(tmp) ;
    xRR = x * S2P(:, idx(1)) ;
    signal(IDX0) = filtfilt(bbb, aaa, xRR) ;
end

% vm is normalized
signal = 99 * signal ./ quantile(signal, .999) ;

t = (1:length(signal))/Hz/60 ; % Time (unit: min)




AMP = zeros(SegNO, 1) ;
AMPTHO = zeros(SegNO, 1) ;
AMPABD = zeros(SegNO, 1) ;
AMPflow = zeros(SegNO, 1) ;

for sIDX = 1: SegNO
    IDX0 = (sIDX-1) * SegLEN + 1: sIDX * SegLEN ;
    tmp = signal(IDX0) ;
    AMP(sIDX) = quantile(abs(tmp), .99) ;
    tmp = thorax(IDX0) ;
    AMPTHO(sIDX) = quantile(abs(tmp), .99) ;
    tmp = abdomen(IDX0) ;
    AMPABD(sIDX) = quantile(abs(tmp), .99) ;
    tmp = airflow(IDX0) ;
    AMPflow(sIDX) = quantile(abs(tmp), .99) ;
end

