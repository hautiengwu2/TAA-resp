tmp = find(ALLLABEL == 1 | ALLLABEL == 2) ;


% inside good/moderate segments, how many are labeled as hypopnea or apnea
tmp1 = length(find(ALLAPNEA(tmp) == 1)) ;
tmp2 = length(find(ALLAPNEA(tmp) == 2)) ;

fprintf('Number of hypopnea/apnea over moderate/good labels\n') ;
disp([tmp1 tmp2 length(tmp)]) ;
%disp([tmp1 tmp2]/tmp) ;

% in the hypopnea or apnea subgroups, how many are labeled as good/moderate
tmp10 = length(find(ALLAPNEA == 1)) ;
tmp20 = length(find(ALLAPNEA == 2)) ;
fprintf('Number of ALL hypopnea/apnea\n') ;
disp([tmp10 tmp20]) ;
fprintf('Ratio of hypopnea/apnea over moderate/good labels\n') ;
disp([tmp1/tmp10 tmp2/tmp20]) ;

[chi2stat, df, p] = chi2cont([tmp10 tmp20 length(ALLAPNEA)-tmp10-tmp20],...
    [tmp1 tmp2 length(tmp)-tmp1-tmp2]);
fprintf('p-val of chi-test for ratio of normal, hypopnea, and apnea over moderate/good labels\n') ;
disp(p)

[h,p,stats] = fishertest([tmp1 tmp2; tmp10 tmp20]) ;
fprintf('p-val of Fisher-test comparing ratio of hypopnea and apnea over moderate/good labels\n') ;
disp(p)


% sleep stages
tmp1 = length(find(ALLSTAGE(tmp) == 11)) ;
tmp2 = length(find(ALLSTAGE(tmp) == 12)) ;
tmp3 = length(find(ALLSTAGE(tmp) == 13)) ;
tmp4 = length(find(ALLSTAGE(tmp) == 14)) ;
tmp5 = length(find(ALLSTAGE(tmp) == 15)) ;
fprintf('Number of sleep stages over moderate/good labels\n') ;
disp([tmp1 tmp2 tmp3 tmp4 tmp5 length(tmp)]) ; 
%disp([tmp1 tmp2 tmp3 tmp4 tmp5]/tmp) ; 

tmp10 = length(find(ALLSTAGE == 11)) ;
tmp20 = length(find(ALLSTAGE == 12)) ;
tmp30 = length(find(ALLSTAGE == 13)) ;
tmp40 = length(find(ALLSTAGE == 14)) ;
tmp50 = length(find(ALLSTAGE == 15)) ;
fprintf('Number of ALL sleep stages\n') ;
disp([tmp10 tmp20 tmp30 tmp40 tmp50]) ;
fprintf('Ratio of sleep stages over moderate/good labels\n') ;
disp([tmp1/tmp10 tmp2/tmp20 tmp3/tmp30 tmp4/tmp40 tmp5/tmp50]) ; 


[chi2stat, df, p] = chi2cont([tmp10 tmp20 tmp30 tmp40 tmp50], ...
    [tmp1 tmp2 tmp3 tmp4 tmp5]);
fprintf('p-val of chi-test for ratio of different sleep stages over moderate/good labels\n') ;
disp(p)
[h,p,stats] = fishertest([tmp5 tmp4; tmp50 tmp40]) ;
fprintf('p-val of Fisher-test comparing ratio of N3 vs N2 over moderate/good labels\n') ;
disp(p)
[h,p,stats] = fishertest([tmp5 tmp3; tmp50 tmp30]) ;
fprintf('p-val of Fisher-test comparing ratio of N3 vs N1 over moderate/good labels\n') ;
disp(p)
[h,p,stats] = fishertest([tmp5 tmp2; tmp50 tmp20]) ;
fprintf('p-val of Fisher-test comparing ratio of N3 vs REM over moderate/good labels\n') ;
disp(p)
[h,p,stats] = fishertest([tmp5 tmp1; tmp50 tmp10]) ;
fprintf('p-val of Fisher-test comparing ratio of N3 vs wake over moderate/good labels\n') ;
disp(p)
