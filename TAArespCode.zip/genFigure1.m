fs = 400 ;
t = (-20000+1:20000) / fs ;
xi = fs * (1:length(t)/2) / length(t) ;
x = cos(2*pi*t) + 0.5*cos(2*pi*2*t+1) ;

L = [5 2.5 1.5 0.5] ;

h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)*2/3]) ;

BDRY = 0.2 ;

for jj = 1: length(L) %length(sigma)
    
    %gv = exp(-t.^2/sigma(jj).^2/2) ;
    gv = zeros(size(x)) ;
    idx = t>=-L(jj)+BDRY & t<=L(jj)-BDRY ;
    gv(idx) = 1 ;
    idx = find(t>L(jj)-BDRY & t<=L(jj)) ;
    if ~isempty(idx)
        gv(idx) = cos(pi * (t(idx)-t(idx(1)))/(t(idx(end))-t(idx(1))) / 2).^2 ;
    end
        
    idx = find(t>=-L(jj) & t<-L(jj)+BDRY) ;
    if ~isempty(idx)
        gv(idx) = sin(pi * (t(idx)-t(idx(1)))/(t(idx(end))-t(idx(1))) / 2).^2 ;
    end
    h = gv .* x ;
    xhat = fft(h) ;

    subplot_tight(length(L), 2, (jj-1)*2 + 1, [0.043 0.05]) ; %length(sigma) changed to length(L)
    plot(t, h, 'k', 'linewidth', 2) ; axis tight ;
    set(gca, 'fontsize', 20) ;
    xlim([-L(1)-1/2 L(1)+1/2]) 
    if jj < length(L) ; set(gca, 'xtick', []) ; %length(sigma) changed to length(L)
    else ; xlabel('Time (s)') ; end

    subplot_tight(length(L), 2, (jj-1)*2 + 2, [0.043 0.05]) ; %length(sigma) changed to length(L)
    plot(xi, abs(xhat(2:end/2+1)), 'k', 'linewidth', 2) ;
    set(gca, 'fontsize', 20) ;
    xlim([0 5]) ;
    if jj < length(L) ; set(gca, 'xtick', []) ; %length(sigma) changed to length(L)
    else ; xlabel('Frequency (Hz)') ; end

end


exportgraphics(h1, 'HowManyCycles.pdf', 'ContentType', 'vector', 'BackgroundColor','none');