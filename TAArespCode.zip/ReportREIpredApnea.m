CM0 = {}; CM1 = {} ; CM2 = {} ;

cvDBIDX = DBIDX(DBIDX <= numel(REI1onlyIMU)) ;
cvDBIDX = cvDBIDX(~cellfun(@isempty, REI1onlyIMU(cvDBIDX))) ;

if numel(cvDBIDX) < 2
    fprintf('Skip ReportREIpredApnea: LOSOCV requires at least 2 analyzed datasets.\n') ;
    return ;
end


% LOSOCV for predicting apnea events from REI
for kk = 1:length(cvDBIDX)

    fprintf(['predict apnea by REI -- LOSOCV of ' num2str(cvDBIDX(kk)) '\n']) ;
    ALLREI1Train = [] ;
    ALLSTAGETrain = [] ;
    ALLAPNEATrain = [] ;
    ALLLABELTrain = [] ;

    for jj = setdiff(cvDBIDX, cvDBIDX(kk))
        ALLREI1Train = [ALLREI1Train; REI1onlyIMU{jj}'] ;
        ALLSTAGETrain = [ALLSTAGETrain; STAGE{jj}'] ;
        ALLAPNEATrain = [ALLAPNEATrain; APNEA{jj}'] ;
        ALLLABELTrain = [ALLLABELTrain; LABEL{jj}] ;
    end



    ALLREI1Test = REI1onlyIMU{cvDBIDX(kk)} ;
    ALLSTAGETest = STAGE{cvDBIDX(kk)}' ;
    ALLAPNEATest = APNEA{cvDBIDX(kk)}' ;
    ALLLABELTest = LABEL{cvDBIDX(kk)}' ;

    

    % moderate+good=1, bad=0 (not used)
    ALLLABELTrain(ALLLABELTrain==2) = 1 ;
    ALLLABELTest(ALLLABELTest==2) = 1 ;


    % only event-free=1 or apnea/hypopnea=0
    ALLAPNEATrain(ALLAPNEATrain>0) = 1 ;
    ALLAPNEATest(ALLAPNEATest>0) = 1 ;
    ALLAPNEATrain = 1 - ALLAPNEATrain ;
    ALLAPNEATest = 1 - ALLAPNEATest ;

    idx = find(ALLAPNEATrain == 1) ;

    % downsample by 3 to balance two groups
    ALLAPNEATrain([idx(1:3:end); idx(2:3:end)]) = [] ;
    ALLREI1Train([idx(1:3:end); idx(2:3:end)]) = [] ;

    % determined optimal threshold for good/bad from the training set
    [AUC10, L, R, optthreshold1, a, b, tidx] = evalROC(ALLAPNEATrain, ALLREI1Train, 0) ;

    
    % apply learned threshold to the testing set
    PredTEST1 = zeros(size(ALLREI1Test)) ; 
    PredTEST1(ALLREI1Test>optthreshold1) = 1 ;
    

    % collect results
    % C=[0->0 0->1 
    %    1->0 1->1] ; 
    % 1 is event-free/high quality
    if length(unique(ALLAPNEATest)) > 1 
        CM1{kk} = confusionmat(ALLAPNEATest, PredTEST1) ;
    else
        tmp1 = [ALLAPNEATest; 1-unique(ALLAPNEATest)] ; 
        
        tmp2 = [PredTEST1 1-unique(ALLAPNEATest)] ;
        CM1{kk} = confusionmat(tmp1, tmp2) ;
        CM1{kk}(1,1) = CM1{kk}(1,1) - 1 ;
    end


    
    [ACC, SEN, SPE, PRE, F1] = PerformanceEvaluation(CM1{kk}) ;
    ACC1(kk) = ACC ;
    SEN1(kk) = SEN ;
    SPE1(kk) = SPE ;
    PRE1(kk) = PRE ;
    F11(kk) = F1 ;
    AUC1(kk) = AUC10 ;

end




idx = find(~isnan(SEN1+SPE1+PRE1+F11)) ;
fprintf(['REI1 -- remove NaN: ' num2str(length(idx)) '/' num2str(length(SEN1)) '\n']) ;
fprintf(['REI1: ACC = ' num2str(mean(ACC1(idx))) '+/-' num2str(std(ACC1(idx))) '\n']) ;
fprintf(['REI1: SEN of event-free = ' num2str(mean(SEN1(idx)))...
    '+/-' num2str(std(SEN1(idx))) '\n']) ;
fprintf(['REI1: SPE of event-free = ' num2str(mean(SPE1(idx)))...
    '+/-' num2str(std(SPE1(idx))) '\n']) ;
fprintf(['REI1: PRE of event-free = ' num2str(mean(PRE1(idx)))...
    '+/-' num2str(std(PRE1(idx))) '\n']) ;
fprintf(['REI1: F1 of event-free = ' num2str(mean(F11(idx)))...
    '+/-' num2str(std(F11(idx))) '\n']) ;
fprintf(['REI1: AUC of event-free = ' num2str(mean(AUC1(idx)))...
    '+/-' num2str(std(AUC1(idx))) '\n\n']) ;


fprintf('REI1 -- replace NaN by 0\n') ;
SEN1(isnan(SEN1)) = 0 ;
SPE1(isnan(SPE1)) = 0 ;
PRE1(isnan(PRE1)) = 0 ;
F11(isnan(F11)) = 0 ;

fprintf(['REI1: ACC = ' num2str(mean(ACC1)) '+/-' num2str(std(ACC1)) '\n']) ;
fprintf(['REI1: SEN of event-free = ' num2str(mean(SEN1))...
    '+/-' num2str(std(SEN1)) '\n']) ;
fprintf(['REI1: SPE of event-free = ' num2str(mean(SPE1))...
    '+/-' num2str(std(SPE1)) '\n']) ;
fprintf(['REI1: PRE of event-free = ' num2str(mean(PRE1))...
    '+/-' num2str(std(PRE1)) '\n']) ;
fprintf(['REI1: F1 of event-free = ' num2str(mean(F11))...
    '+/-' num2str(std(F11)) '\n']) ;
fprintf(['REI1: AUC of event-free = ' num2str(mean(AUC1))...
    '+/-' num2str(std(AUC1)) '\n\n']) ;
